export class CreateMemberDto {
    userId: number;
    username: string;
    memberSinceDate: string;
}
