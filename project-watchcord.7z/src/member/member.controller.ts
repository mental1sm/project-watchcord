import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { MemberService } from './member.service';
import { CreateMemberDto } from './dto/create-member.dto';
import { UpdateMemberDto } from './dto/update-member.dto';
import { ApiOkResponse, ApiOperation, ApiTags } from '@nestjs/swagger';
import { DiscordClientService } from '../discord_client/discord.client.service';
import { BotService } from '../bot/bot.service';
import { Member } from './entities/member.entity';


@ApiTags('Member')
@Controller('bot/:appId/guilds/:guildId/members')
export class MemberController {
  constructor(
    private readonly memberService: MemberService,
    private readonly discordClient: DiscordClientService,
    private readonly botService: BotService
  ) {}

  @Post()
  @ApiOperation({summary: 'Fetch all Members from Discord API'})
  @ApiOkResponse({description: "Found successfully", type: Member, isArray: true})
  async fetchAll(@Param('appId') appId: string, @Param('guildId') guildId: string) {
    const bot = await this.botService.findOne(appId);
    this.discordClient.setBot(bot);
    return this.memberService.fetchAll(guildId);
  }

  @Post(':memberId')
  @ApiOperation({summary: 'Fetch Member from Discord API'})
  @ApiOkResponse({description: "Found successfully", type: Member, isArray: false})
  async fetch(
    @Param('memberId') memberId: string,
    @Param('guildId') guildId: string,
    @Param('appId') appId: string,
  ) {
    const bot = await this.botService.findOne(appId);
    this.discordClient.setBot(bot);
    return this.memberService.fetch(guildId, memberId);
  }

  @Get()
  @ApiOperation({summary: 'Fetch all Members from Database'})
  @ApiOkResponse({description: "Found successfully", type: Member, isArray: false})
  findAll() {
    return this.memberService.findAll();
  }

  @Get(':memberId')
  @ApiOperation({summary: 'Fetch Member from Database'})
  @ApiOkResponse({description: "Found successfully", type: Member, isArray: false})
  find(@Param('memberId') memberId: string) {
    return this.memberService.findOne(memberId);
  }
}
