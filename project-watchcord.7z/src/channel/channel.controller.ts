import { Controller, Get, Post, Body, Patch, Param, Delete, HttpStatus } from '@nestjs/common';
import { ChannelService } from './channel.service';
import { DiscordClientService } from '../discord_client/discord.client.service';
import { BotService } from '../bot/bot.service';
import { ApiOkResponse, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { Channel } from './entities/channel.entity';

@ApiTags('Channel')
@Controller('bot/:appId/guilds/:guildId/channels')
export class ChannelController {
  constructor(
    private readonly channelService: ChannelService,
    private readonly discordClient: DiscordClientService,
    private readonly botService: BotService
  ) {}

  @Post()
  @ApiOperation({summary: 'Fetch all channels from Discord API' })
  @ApiOkResponse({description: "Fetched successfully", type: Channel, isArray: true})
  async fetchAll(@Param('appId') appId: string, @Param('guildId') guildId: string) {
    const bot = await this.botService.findOne(appId);
    this.discordClient.setBot(bot);
    return this.channelService.fetchAll(guildId);
  }

  @ApiOperation({summary: 'Fetch channel from Discord API'})
  @ApiOkResponse({description: "Fetched successfully", type: Channel, isArray: false})
  @Post(':channelId')
  async fetch(@Param('channelId') channelId: string, @Param('appId') appId: string) {
    const bot = await this.botService.findOne(appId);
    this.discordClient.setBot(bot);
    return this.channelService.fetch(channelId);
  }

  @Get()
  @ApiOperation({summary: 'Find all channels from Database'})
  @ApiOkResponse({description: "Found successfully", type: Channel, isArray: true})
  findAll(@Param('guildId') guildId: string) {
    return this.channelService.findAll(guildId);
  }

  @Get(':channelId')
  @ApiOperation({summary: 'Find specified Channel from Database'})
  @ApiOkResponse({description: "Found successfully", type: Channel, isArray: false})
  findOne(@Param('channelId') channelId: string) {
    return this.channelService.findOne(channelId);
  }
}
